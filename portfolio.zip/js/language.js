// Language support functionality
document.addEventListener('DOMContentLoaded', function() {
    // Language toggle functionality
    const languageToggle = document.getElementById('language-toggle');
    const languageDropdown = document.querySelector('.language-dropdown');
    const languageOptions = document.querySelectorAll('.language-dropdown a');
    
    // Set default language
    let currentLang = 'en';
    document.documentElement.lang = currentLang;
    
    // Toggle dropdown visibility
    if (languageToggle) {
        languageToggle.addEventListener('click', function() {
            if (languageDropdown.style.display === 'block') {
                languageDropdown.style.display = 'none';
            } else {
                languageDropdown.style.display = 'block';
            }
        });
    }
    
    // Language selection
    languageOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();
            const lang = this.getAttribute('data-lang');
            changeLanguage(lang);
            languageDropdown.style.display = 'none';
        });
    });
    
    // Change language function
    function changeLanguage(lang) {
        document.documentElement.lang = lang;
        currentLang = lang;
        
        // Update language toggle text
        languageToggle.querySelector('span').textContent = lang.toUpperCase();
        
        // Update content visibility based on language
        const allLangElements = document.querySelectorAll('[data-lang]');
        allLangElements.forEach(el => {
            if (el.getAttribute('data-lang') === lang) {
                el.style.display = 'block';
            } else {
                el.style.display = 'none';
            }
        });
    }
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.language-selector') && languageDropdown.style.display === 'block') {
            languageDropdown.style.display = 'none';
        }
    });
});
