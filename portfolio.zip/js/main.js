/**
 * Main JavaScript for Cristiano Silva's Portfolio
 * Theme: Futuristic AI-Style
 */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize components
    initParticles();
    initTypingEffect();
    initScrollAnimation();
    initSkillsTabs();
    initProjectCards();
    initAIAssistant();
    initNavigation();
    initContactForm();
    initNeuralNetwork();
});

// Initialize particles background
function initParticles() {
    particlesJS('particles-js', {
        particles: {
            number: {
                value: 80,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: '#64FFDA'
            },
            shape: {
                type: 'circle',
                stroke: {
                    width: 0,
                    color: '#000000'
                },
                polygon: {
                    nb_sides: 5
                }
            },
            opacity: {
                value: 0.5,
                random: false,
                anim: {
                    enable: false,
                    speed: 1,
                    opacity_min: 0.1,
                    sync: false
                }
            },
            size: {
                value: 3,
                random: true,
                anim: {
                    enable: false,
                    speed: 40,
                    size_min: 0.1,
                    sync: false
                }
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: '#00BFFF',
                opacity: 0.4,
                width: 1
            },
            move: {
                enable: true,
                speed: 2,
                direction: 'none',
                random: false,
                straight: false,
                out_mode: 'out',
                bounce: false,
                attract: {
                    enable: false,
                    rotateX: 600,
                    rotateY: 1200
                }
            }
        },
        interactivity: {
            detect_on: 'canvas',
            events: {
                onhover: {
                    enable: true,
                    mode: 'grab'
                },
                onclick: {
                    enable: true,
                    mode: 'push'
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 140,
                    line_linked: {
                        opacity: 1
                    }
                },
                bubble: {
                    distance: 400,
                    size: 40,
                    duration: 2,
                    opacity: 8,
                    speed: 3
                },
                repulse: {
                    distance: 200,
                    duration: 0.4
                },
                push: {
                    particles_nb: 4
                },
                remove: {
                    particles_nb: 2
                }
            }
        },
        retina_detect: true
    });
}

// Initialize typing effect
function initTypingEffect() {
    const options = {
        strings: [
            'Biomedical Instrumentation Technician',
            'AI & Machine Learning Specialist',
            'Healthcare Technology Expert',
            'Medical Device Engineer'
        ],
        typeSpeed: 50,
        backSpeed: 30,
        backDelay: 2000,
        loop: true
    };
    
    if (document.querySelector('.typing')) {
        new Typed('.typing', options);
    }
}

// Initialize scroll animations
function initScrollAnimation() {
    // Progress bar
    window.addEventListener('scroll', function() {
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        document.querySelector('.progress-indicator').style.width = scrolled + '%';
    });
    
    // Navigation highlight based on scroll position
    window.addEventListener('scroll', function() {
        const sections = document.querySelectorAll('section');
        const navLinks = document.querySelectorAll('.nav-link');
        
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            if (pageYOffset >= (sectionTop - sectionHeight / 3)) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === '#' + current) {
                link.classList.add('active');
            }
        });
        
        // Sticky navigation
        const nav = document.querySelector('.nav-container');
        if (window.scrollY > 100) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }
    });
    
    // Reveal animations on scroll
    const revealElements = document.querySelectorAll('.section-header, .about-content, .skills-categories, .timeline-item, .project-card, .education-card, .contact-container');
    
    const revealOnScroll = function() {
        revealElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementTop < windowHeight - 100) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    };
    
    // Set initial styles
    revealElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    });
    
    // Run on load and scroll
    window.addEventListener('load', revealOnScroll);
    window.addEventListener('scroll', revealOnScroll);
}

// Initialize skills tabs
function initSkillsTabs() {
    const tabs = document.querySelectorAll('.category-tab');
    const skillGrids = document.querySelectorAll('.skills-grid');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            tab.classList.add('active');
            
            // Hide all skill grids
            skillGrids.forEach(grid => grid.classList.remove('active'));
            
            // Show the corresponding skill grid
            const category = tab.getAttribute('data-category');
            document.getElementById(category + '-skills').classList.add('active');
        });
    });
}

// Initialize project cards
function initProjectCards() {
    // Add hover effect for project cards
    const projectCards = document.querySelectorAll('.project-card');
    
    projectCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'scale(1.03)';
            card.style.transition = 'transform 0.3s ease';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'scale(1)';
        });
    });
}

// Initialize AI Assistant
function initAIAssistant() {
    const aiButton = document.querySelector('.ai-button');
    const aiChatContainer = document.querySelector('.ai-chat-container');
    const closeChat = document.querySelector('.close-chat');
    const sendMessage = document.querySelector('.send-message');
    const chatInput = document.querySelector('.ai-chat-input input');
    const chatMessages = document.querySelector('.ai-chat-messages');
    
    // Toggle chat container
    aiButton.addEventListener('click', () => {
        if (aiChatContainer.style.display === 'flex') {
            aiChatContainer.style.display = 'none';
        } else {
            aiChatContainer.style.display = 'flex';
            chatInput.focus();
        }
    });
    
    // Close chat
    closeChat.addEventListener('click', () => {
        aiChatContainer.style.display = 'none';
    });
    
    // Send message
    function sendUserMessage() {
        const message = chatInput.value.trim();
        if (message) {
            // Add user message
            const userMessageHTML = `
                <div class="ai-message user-message">
                    <div class="message-content user-content">
                        <p>${message}</p>
                    </div>
                </div>
            `;
            chatMessages.innerHTML += userMessageHTML;
            
            // Clear input
            chatInput.value = '';
            
            // Scroll to bottom
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            // Simulate AI response after a short delay
            setTimeout(() => {
                respondToMessage(message);
            }, 1000);
        }
    }
    
    sendMessage.addEventListener('click', sendUserMessage);
    
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendUserMessage();
        }
    });
    
    // AI response logic
    function respondToMessage(message) {
        let response = "I'm sorry, I don't understand that question. Can you try asking about Cristiano's skills, experience, or projects?";
        
        // Simple keyword matching for demo purposes
        message = message.toLowerCase();
        
        if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
            response = "Hello! How can I help you learn more about Cristiano's portfolio?";
        } else if (message.includes('skills') || message.includes('what can you do')) {
            response = "Cristiano specializes in Biomedical Instrumentation with expertise in AI and medical technologies. His technical skills include Next.js, Flutter, Python, Machine Learning, and more!";
        } else if (message.includes('experience') || message.includes('work')) {
            response = "Cristiano has experience at Grupo Electromédica as a Biomedical Instrumentation Technician, at SAFE AI [4U] working with AI/Machine Learning, and at Instituto Superior de Engenharia de Coimbra focusing on Biomedical Instrumentation.";
        } else if (message.includes('education') || message.includes('study')) {
            response = "Cristiano has a Biomedical Engineering Degree from Instituto Superior de Engenharia de Coimbra, with focus on bioinstrumentation, signal processing, and medical devices.";
        } else if (message.includes('contact') || message.includes('email')) {
            response = "You can contact Cristiano via email at silvacristiano0508@gmail.com or use the contact form in the Contact section.";
        } else if (message.includes('project')) {
            response = "Cristiano has worked on various projects including biosignal processing systems, medical device integration platforms, AI-powered health monitoring, and mobile health applications. Check out the Projects section for more details!";
        } else if (message.includes('language')) {
            response = "Cristiano speaks Portuguese (native), English (fluent), and French (basic).";
        } else if (message.includes('thank')) {
            response = "You're welcome! Feel free to ask if you have any other questions about Cristiano's work or skills.";
        }
        
        // Add AI response
        const aiMessageHTML = `
            <div class="ai-message">
                <div class="ai-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="message-content">
                    <p>${response}</p>
                </div>
            </div>
        `;
        chatMessages.innerHTML += aiMessageHTML;
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
}

// Initialize navigation
function initNavigation() {
    // Mobile menu toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    mobileMenuBtn.addEventListener('click', () => {
        mobileMenuBtn.classList.toggle('active');
        
        if (navLinks.style.display === 'flex') {
            navLinks.style.display = 'none';
        } else {
            navLinks.style.display = 'flex';
            navLinks.style.flexDirection = 'column';
            navLinks.style.position = 'absolute';
            navLinks.style.top = '80px';
            navLinks.style.left = '0';
            navLinks.style.width = '100%';
            navLinks.style.padding = '2rem';
            navLinks.style.backgroundColor = 'rgba(10, 25, 47, 0.95)';
            navLinks.style.backdropFilter = 'blur(10px)';
            navLinks.style.zIndex = '1000';
        }
    });
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Close mobile menu if open
            if (window.innerWidth < 992 && navLinks.style.display === 'flex') {
                navLinks.style.display = 'none';
                mobileMenuBtn.classList.remove('active');
            }
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80, // Adjust for header height
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Theme toggle
    const themeToggle = document.getElementById('theme-toggle');
    let isDarkTheme = true; // Default is dark theme
    
    themeToggle.addEventListener('click', () => {
        if (isDarkTheme) {
            // Switch to light theme
            document.documentElement.style.setProperty('--bg-dark', '#f0f5ff');
            document.documentElement.style.setProperty('--primary-dark', '#ffffff');
            document.documentElement.style.setProperty('--text-primary', '#0A192F');
            document.documentElement.style.setProperty('--text-secondary', '#4a5568');
            document.documentElement.style.setProperty('--bg-card', 'rgba(255, 255, 255, 0.7)');
            document.documentElement.style.setProperty('--bg-card-hover', 'rgba(255, 255, 255, 0.9)');
            
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
            // Switch back to dark theme
            document.documentElement.style.setProperty('--bg-dark', '#0a1021');
            document.documentElement.style.setProperty('--primary-dark', '#0A192F');
            document.documentElement.style.setProperty('--text-primary', '#E6F1FF');
            document.documentElement.style.setProperty('--text-secondary', '#8892B0');
            document.documentElement.style.setProperty('--bg-card', 'rgba(16, 26, 58, 0.7)');
            document.documentElement.style.setProperty('--bg-card-hover', 'rgba(22, 33, 70, 0.9)');
            
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        }
        
        isDarkTheme = !isDarkTheme;
    });
    
    // Language toggle functionality
    const languageToggle = document.getElementById('language-toggle');
    const languageOptions = document.querySelectorAll('.language-dropdown a');
    
    languageOptions.forEach(option => {
        option.addEventListener('click', (e) => {
            e.preventDefault();
            const lang = option.getAttribute('data-lang');
            languageToggle.querySelector('span').textContent = lang.toUpperCase();
            
            // Here you would implement actual language switching logic
            // For demo purposes, we'll just update the toggle button
        });
    });
}

// Initialize contact form
function initContactForm() {
    const contactForm = document.getElementById('contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;
            
            // Validate form (simple validation for demo)
            if (!name || !email || !subject || !message) {
                alert('Please fill in all fields');
                return;
            }
            
            // Simulate form submission
            const submitBtn = contactForm.querySelector('.submit-btn');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<span>Sending...</span> <i class="fas fa-spinner fa-spin"></i>';
            submitBtn.disabled = true;
            
            // Simulate API call
            setTimeout(() => {
                // Reset form
                contactForm.reset();
                
                // Show success message
                submitBtn.innerHTML = '<span>Sent Successfully!</span> <i class="fas fa-check"></i>';
                
                // Reset button after delay
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 3000);
            }, 2000);
        });
    }
}

// Initialize neural network visualization
function initNeuralNetwork() {
    const neuralNetworkContainer = document.querySelector('.neural-network');
    
    if (neuralNetworkContainer && window.THREE) {
        // Set up scene
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, neuralNetworkContainer.clientWidth / neuralNetworkContainer.clientHeight, 0.1, 1000);
        
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(neuralNetworkContainer.clientWidth, neuralNetworkContainer.clientHeight);
        neuralNetworkContainer.appendChild(renderer.domElement);
        
        // Create neural network nodes
        const nodes = [];
        const connections = [];
        const layers = 4;
        const nodesPerLayer = [5, 8, 8, 4];
        const layerDistance = 2;
        
        // Create geometry for nodes
        const nodeGeometry = new THREE.SphereGeometry(0.1, 16, 16);
        
        // Create materials
        const activeMaterial = new THREE.MeshBasicMaterial({ color: 0x64FFDA });
        const inactiveMaterial = new THREE.MeshBasicMaterial({ color: 0x8892B0 });
        const connectionMaterial = new THREE.LineBasicMaterial({ color: 0x00BFFF, transparent: true, opacity: 0.3 });
        
        // Create nodes
        for (let l = 0; l < layers; l++) {
            const layerNodes = [];
            const layerX = (l - (layers - 1) / 2) * layerDistance;
            
            for (let n = 0; n < nodesPerLayer[l]; n++) {
                const nodeY = (n - (nodesPerLayer[l] - 1) / 2) * 0.5;
                
                const nodeMesh = new THREE.Mesh(nodeGeometry, inactiveMaterial.clone());
                nodeMesh.position.set(layerX, nodeY, 0);
                scene.add(nodeMesh);
                
                layerNodes.push(nodeMesh);
            }
            
            nodes.push(layerNodes);
        }
        
        // Create connections between layers
        for (let l = 0; l < layers - 1; l++) {
            for (let n1 = 0; n1 < nodesPerLayer[l]; n1++) {
                for (let n2 = 0; n2 < nodesPerLayer[l + 1]; n2++) {
                    const startNode = nodes[l][n1];
                    const endNode = nodes[l + 1][n2];
                    
                    const points = [startNode.position, endNode.position];
                    const geometry = new THREE.BufferGeometry().setFromPoints(points);
                    const line = new THREE.Line(geometry, connectionMaterial.clone());
                    
                    scene.add(line);
                    connections.push({
                        line: line,
                        start: startNode,
                        end: endNode,
                        active: false
                    });
                }
            }
        }
        
        // Position camera
        camera.position.z = 5;
        
        // Animation function
        function animate() {
            requestAnimationFrame(animate);
            
            // Rotate the entire network slightly
            scene.rotation.y += 0.002;
            scene.rotation.x = Math.sin(Date.now() * 0.0005) * 0.1;
            
            // Randomly activate nodes and connections
            if (Math.random() < 0.05) {
                const layerIndex = Math.floor(Math.random() * layers);
                const nodeIndex = Math.floor(Math.random() * nodesPerLayer[layerIndex]);
                
                const node = nodes[layerIndex][nodeIndex];
                node.material = activeMaterial.clone();
                
                setTimeout(() => {
                    node.material = inactiveMaterial.clone();
                }, 500);
                
                // Activate connections from this node
                connections.forEach(conn => {
                    if (conn.start === node || conn.end === node) {
                        conn.line.material.opacity = 0.8;
                        conn.line.material.color.set(0x64FFDA);
                        
                        setTimeout(() => {
                            conn.line.material.opacity = 0.3;
                            conn.line.material.color.set(0x00BFFF);
                        }, 500);
                    }
                });
            }
            
            renderer.render(scene, camera);
        }
        
        // Handle window resize
        window.addEventListener('resize', () => {
            camera.aspect = neuralNetworkContainer.clientWidth / neuralNetworkContainer.clientHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(neuralNetworkContainer.clientWidth, neuralNetworkContainer.clientHeight);
        });
        
        // Start animation
        animate();
    }
}
